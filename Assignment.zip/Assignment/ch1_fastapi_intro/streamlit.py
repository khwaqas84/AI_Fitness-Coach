import requests
import streamlit as st

API_URL = "http://localhost:8000/workout-plan"

st.title("Personalized Workout Plan Generator")
st.write("Help us understand your fitness goals to create a custom workout plan!")

goals = st.selectbox("What are your fitness goals?", ["Weight Loss", "Muscle Gain", "Endurance", "Flexibility"])
fitness_level = st.radio("Current Fitness Level", ["Beginner", "Intermediate", "Advanced"])
workout_preferences = st.multiselect("Workout Preferences", ["Home Workouts", "Gym Workouts", "Outdoor Activities", "Yoga/Pilates"])
equipment = st.multiselect("Available Equipment", ["Dumbbells", "Resistance Bands", "Cardio Machines", "No Equipment"])
commitment = st.slider("How many days per week can you commit?", 1, 7, 3)
session_length = st.slider("Average workout duration (minutes)", 30, 90, 45)
injury_history = st.text_input("Do you have any injury history? Please specify if any.")

if st.button("Generate Workout Plan"):
    payload = {
        "goals": goals,
        "fitness_level": fitness_level,
        "workout_preferences": workout_preferences,
        "equipment": equipment,
        "commitment": commitment,
        "session_length": session_length,
        "injury_history": injury_history,
    }

    with st.spinner("Generating your personalized workout plan..."):
        try:
            response = requests.post(API_URL, json=payload, timeout=60)
            response.raise_for_status()
            st.markdown(response.json()["plan"])
        except requests.exceptions.ConnectionError:
            st.error("Can't reach the API. Is FastAPI running on port 8000?")
        except requests.exceptions.HTTPError:
            detail = response.json().get("detail", response.text)
            st.error(f"API error: {detail}")
        except requests.exceptions.Timeout:
            st.error("The request timed out. Please try again.")