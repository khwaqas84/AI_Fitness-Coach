import os
from typing import List

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from groq import Groq
from pydantic import BaseModel, Field

load_dotenv()

app = FastAPI(title="Workout Plan API")


class WorkoutRequest(BaseModel):
    goals: str
    fitness_level: str
    workout_preferences: List[str] = []
    equipment: List[str] = []
    commitment: int = Field(..., ge=1, le=7)
    session_length: int = Field(..., ge=10, le=180)
    injury_history: str = ""


class WorkoutResponse(BaseModel):
    plan: str


def generate_workout_plan(data: WorkoutRequest) -> str:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="Missing GROQ_API_KEY")

    client = Groq(api_key=api_key)
    model = os.getenv("GROQ_MODEL", "openai/gpt-oss-20b")

    system_prompt = (
        "You are an experienced fitness coach. Create a clear, structured weekly "
        "workout plan. Respect the user's equipment, schedule, and injury history. "
        "Avoid exercises that could aggravate stated injuries. Use markdown with a "
        "heading per day, and include sets, reps, and rest. End with a short note "
        "recommending they consult a doctor or physiotherapist if they have injuries "
        "or medical conditions."
    )

    user_prompt = f"""
Create a workout plan with these details:
- Goal: {data.goals}
- Fitness level: {data.fitness_level}
- Preferences: {', '.join(data.workout_preferences) or 'None specified'}
- Equipment: {', '.join(data.equipment) or 'None specified'}
- Days per week: {data.commitment}
- Session length: {data.session_length} minutes
- Injury history: {data.injury_history or 'None'}
"""

    try:
        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.7,
            max_tokens=1500,
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Groq error: {e}")

    plan = completion.choices[0].message.content
    if not plan:
        raise HTTPException(status_code=502, detail="LLM returned an empty plan")
    return plan.strip()


@app.post("/workout-plan", response_model=WorkoutResponse)
def workout_plan(request: WorkoutRequest):
    return {"plan": generate_workout_plan(request)}